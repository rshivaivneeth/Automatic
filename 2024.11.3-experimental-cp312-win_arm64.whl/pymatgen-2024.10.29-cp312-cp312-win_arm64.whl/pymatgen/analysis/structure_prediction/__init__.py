"""Utilities to predict new structures."""
