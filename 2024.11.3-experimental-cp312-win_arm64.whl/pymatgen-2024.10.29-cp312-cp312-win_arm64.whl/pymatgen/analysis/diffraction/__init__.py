"""This package implements various diffraction analyses."""
