"""Module for predicting theoretical solar-cell efficiency."""
