"""This package contains various command line interfaces for common
pymatgen functionality such as file conversion, etc. Entry points to these
interfaces are defined in setup.py.
"""
