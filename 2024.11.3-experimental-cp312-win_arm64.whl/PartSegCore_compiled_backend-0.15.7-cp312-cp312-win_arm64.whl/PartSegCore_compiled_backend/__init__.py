from PartSegCore_compiled_backend.version import __version__

__all__ = ['__version__']
