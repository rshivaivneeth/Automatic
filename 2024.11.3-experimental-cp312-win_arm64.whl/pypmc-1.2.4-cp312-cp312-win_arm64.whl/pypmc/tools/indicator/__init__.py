'''Collect generators of typical indicator functions.

'''

# import these submodules by default
from ._indicator_factory import *
from ._indicator_merge import *
