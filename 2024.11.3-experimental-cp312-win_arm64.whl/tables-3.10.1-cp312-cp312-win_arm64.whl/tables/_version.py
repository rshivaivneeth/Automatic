__version__ = "3.10.1"
"""The PyTables version number."""
