"""Utility scripts for PyTables.

This package contains some modules which provide a ``main()`` function
(with no arguments), so that they can be used as scripts.

"""
