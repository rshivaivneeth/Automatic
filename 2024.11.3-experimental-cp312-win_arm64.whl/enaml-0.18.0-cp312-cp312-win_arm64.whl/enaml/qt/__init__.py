# ------------------------------------------------------------------------------
# Copyright (c) 2013-2024, Nucleic Development Team.
#
# Distributed under the terms of the Modified BSD License.
#
# The full license is in the file LICENSE, distributed with this software.
# ------------------------------------------------------------------------------
from qtpy import (
    API as QT_API,
    PYQT5_API,
    PYSIDE2_API,
    PYQT6_API,
    PYSIDE6_API,
    QT_VERSION,
)
