Authors
=======

* Developer of the original ImageJ plugins TurboReg/StackReg: Philippe Thévenaz  (http://bigwww.epfl.ch/thevenaz/)
* Developer of this package (Port of the Java code from P. Thévenaz to C++ and Python wrapper): Gregor Lichtner `@glichtner <https://github.com/glichtner>`_
