# ptufile/__main__.py

"""ptufile package command line script."""

import sys

from .ptufile import main

sys.exit(main())
